SNESCE ROM TOOL v1.1 By DNA64

How to use this:

This program will take any .sfc or .smc file, convert it to .sfrom 
using the Python script Valter released on GBATemp, and then give 
it a random name like CLV-P-DNA64 to the file and move into a folder 
under the same random name (CLV-P-DNA64).

To use this program just make a new folder on your desktop and drop the 
"SNESCE_ROM_TOOL[DNA64].bat" file inside with the sfc2sfrom.py script 
(Requires Python 3.6.0). 

Then add the .sfc or .smc ROM you want to convert and launch the 
"SNESCE_ROM_TOOL[DNA64].bat" program. Once you have verified this file works
you can run the "1-click-convert[DNA64].bat" for faster conversions.

I'm including the current build of sfc2sfrom.py which I have and will continue to update.

You can check for updates here:
https://gist.github.com/DNA64/5e79c6449785949f86744fa7dcb50ad7#file-sfc2sfrom-py

CHANGELOG:

October 5th, 2017
Release v1.1

Fixed typo that did not affect function.
Included 1-click-convert[DNA64].bat
UPDATED README.TXT

------------------

October 5th, 2017
Release v1.0

Included SNESCE_ROM_TOOL[DNA64].bat
Included README.TXT
Included sfc2sfrom.py

- Enjoy!